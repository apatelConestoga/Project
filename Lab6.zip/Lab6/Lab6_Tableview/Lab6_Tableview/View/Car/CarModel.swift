//
//  CarModel.swift
//  Lab6_Tableview
//
//  Created by Adeesh on 2024-07-07.
//

import UIKit

struct Car {
    var image: UIImage?
    var make: String?
    var model: String?
}
